<?php

$email = "example@gmail.com";

?>